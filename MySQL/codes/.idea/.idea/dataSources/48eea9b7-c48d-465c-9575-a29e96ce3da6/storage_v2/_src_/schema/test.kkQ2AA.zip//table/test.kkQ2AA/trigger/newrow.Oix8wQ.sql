create definer = root@localhost trigger newRow
    after insert
    on test
    for each row
    SELECT 'Product added' INTO @message;

