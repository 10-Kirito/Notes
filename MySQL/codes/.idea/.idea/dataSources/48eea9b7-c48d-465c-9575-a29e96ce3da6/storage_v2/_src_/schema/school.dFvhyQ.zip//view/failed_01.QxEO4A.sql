create definer = root@localhost view failed_01 as
select `s`.`student_id`   AS `student_id`,
       `s`.`student_name` AS `student_name`,
       `s`.`gender`       AS `gender`,
       `s`.`phone_number` AS `phone_number`,
       `c`.`class_name`   AS `class_name`,
       `sc`.`score`       AS `score`
from ((`school`.`student` `s` join `school`.`select_class` `sc`
       on ((`s`.`student_id` = `sc`.`student_id`))) join `school`.`class` `c` on ((`sc`.`class_id` = `c`.`class_id`)))
where ((`s`.`yxh` = '01') and (`sc`.`score` < 60));

