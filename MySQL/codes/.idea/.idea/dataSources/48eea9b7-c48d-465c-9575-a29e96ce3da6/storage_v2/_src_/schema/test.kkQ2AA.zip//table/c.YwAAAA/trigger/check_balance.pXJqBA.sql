create definer = root@localhost trigger check_balance
    before insert
    on c
    for each row
begin
    if ((select balance from E where eno = new.eno) - new.expend < -1000)
        then
                SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Overdraft is not allowed';
    end if;
end;

