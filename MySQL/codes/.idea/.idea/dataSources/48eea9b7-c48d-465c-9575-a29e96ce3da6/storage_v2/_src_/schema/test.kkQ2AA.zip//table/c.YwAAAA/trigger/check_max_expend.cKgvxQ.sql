create definer = root@localhost trigger check_max_expend
    before insert
    on c
    for each row
begin
        declare current_expend decimal(10, 2);
        set current_expend = (select sum(expend) from C where date = new.date);
        if (current_expend + new.expend > (select maxexpend from E where E.eno = new.eno))
            then
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Overdraft is not allowed';
        end if;
    end;

