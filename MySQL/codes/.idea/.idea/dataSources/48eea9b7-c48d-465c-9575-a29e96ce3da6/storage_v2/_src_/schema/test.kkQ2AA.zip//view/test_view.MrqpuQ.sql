create definer = root@localhost view test_view as
select `test`.`test`.`id` AS `id`
from `test`.`test`;

