create definer = root@localhost trigger newOrder
    after insert
    on test
    for each row
    select id as i
             from NEW into @test;

