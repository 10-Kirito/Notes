create definer = root@localhost trigger update_total_score
    before update
    on select_class
    for each row
BEGIN
   IF NEW.usually_score IS NULL OR NEW.test_score IS NULL THEN
       SET NEW.total_score = NULL;
    ELSE
       SET NEW .total_score = NEW.usually_score * 0.3 + NEW.test_score*0.7;
   end if;
END;

