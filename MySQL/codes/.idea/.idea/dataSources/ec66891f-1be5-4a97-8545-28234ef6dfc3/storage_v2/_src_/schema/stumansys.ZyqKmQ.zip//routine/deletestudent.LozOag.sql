create
    definer = root@`%` procedure deletestudent(IN targetid int)
begin
    delete from lessonchoose where snumber=targetid;
    delete from student where studentid=targetid;
end;

