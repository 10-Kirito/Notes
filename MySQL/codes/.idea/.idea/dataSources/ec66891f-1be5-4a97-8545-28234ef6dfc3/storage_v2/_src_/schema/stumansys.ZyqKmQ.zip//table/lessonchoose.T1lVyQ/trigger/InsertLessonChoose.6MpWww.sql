create definer = root@`%` trigger InsertLessonChoose
    before insert
    on lessonchoose
    for each row
BEGIN
    DECLARE current_size INT;
    DECLARE max_size INT;
    
    SELECT currentsize INTO current_size FROM sclass WHERE Lnumber = NEW.Lnumber AND Tnumber = NEW.Tnumber And semester = NEW.semester;
    SELECT maxsize INTO max_size FROM sclass WHERE Lnumber = NEW.Lnumber AND Tnumber = NEW.Tnumber And semester = NEW.semester;
    
    IF current_size >= max_size THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'The current class size has reached the maximum capacity';
    END IF;
END;

