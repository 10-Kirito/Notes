create definer = root@`%` trigger tri_update_score
    before update
    on lessonchoose
    for each row
BEGIN
        DECLARE total_marks FLOAT;
        DECLARE grade_point FLOAT;
        DECLARE ps_mark FLOAT;
        DECLARE exam_mark FLOAT;
        DECLARE ps_weightage INT;
        DECLARE exam_weightage INT;

        SELECT SUBSTR(gradeindex, 1, 1), SUBSTR(gradeindex, 2, 1) INTO ps_weightage, exam_weightage
        FROM lesson
        WHERE Lnumber = NEW.Lnumber;

        SET ps_mark = NEW.psgrade;
        SET exam_mark = NEW.ksgrade;

        SET total_marks = (ps_mark * ps_weightage / 10) + (exam_mark * exam_weightage / 10);

        IF total_marks >= 90 THEN SET grade_point = 4.0;
        ELSEIF total_marks >= 85 THEN SET grade_point = 3.7;
        ELSEIF total_marks >= 82 THEN SET grade_point = 3.3;
        ELSEIF total_marks >= 78 THEN SET grade_point = 3.0;
        ELSEIF total_marks >= 75 THEN SET grade_point = 2.7;
        ELSEIF total_marks >= 72 THEN SET grade_point = 2.3;
        ELSEIF total_marks >= 68 THEN SET grade_point = 2.0;
        ELSEIF total_marks >= 64 THEN SET grade_point = 1.5;
        ELSEIF total_marks >= 60 THEN SET grade_point = 1.0;
        ELSEIF total_marks >= 0 THEN SET grade_point = 0.0;
        END IF;

        SET NEW.totalgrade = total_marks;
        SET NEW.GPA = grade_point;
    END;

